import './config/env.js';
import { connectDb } from './config/db.js';
import {
  Organization,
  User,
  Profile,
  Teacher,
  Parent,
  Student,
  ClassModel,
  StudentParent,
  Notice,
} from './models/index.js';

async function seed() {
  await connectDb();

  await Promise.all([
    Notice.deleteMany({}),
    StudentParent.deleteMany({}),
    Student.deleteMany({}),
    ClassModel.deleteMany({}),
    Parent.deleteMany({}),
    Teacher.deleteMany({}),
    Profile.deleteMany({}),
    User.deleteMany({}),
    Organization.deleteMany({}),
  ]);

  const [greenwood, sunrise] = await Organization.insertMany([
    {
      name: 'Greenwood Academy',
      code: 'GWA',
      address: '12 Park Avenue, Delhi',
      phone: '+91 98765 43210',
      email: 'info@greenwood.edu',
      active: true,
    },
    {
      name: 'Sunrise Public School',
      code: 'SPS',
      address: '88 Lake Road, Mumbai',
      phone: '+91 99887 76655',
      email: 'hello@sunrise.edu',
      active: true,
    },
  ]);

  const password = 'password123';

  async function makeUserProfile({ email, full_name, role, organization_id, phone }) {
    const user = await User.create({ email, password });
    const profile = await Profile.create({
      user_id: user._id,
      email,
      full_name,
      role,
      organization_id: organization_id || null,
      phone: phone || null,
    });
    return profile;
  }

  const superAdmin = await makeUserProfile({
    email: 'superadmin@educore.edu',
    full_name: 'Super Admin',
    role: 'super_admin',
  });

  const admin = await makeUserProfile({
    email: 'admin@greenwood.edu',
    full_name: 'Greenwood Admin',
    role: 'admin',
    organization_id: greenwood._id,
    phone: '+91 90000 11111',
  });

  const teacherProfile = await makeUserProfile({
    email: 'sarah.j@greenwood.edu',
    full_name: 'Sarah Johnson',
    role: 'teacher',
    organization_id: greenwood._id,
    phone: '+91 90000 22222',
  });

  const studentProfile = await makeUserProfile({
    email: 'rahul.k@greenwood.edu',
    full_name: 'Rahul Kumar',
    role: 'student',
    organization_id: greenwood._id,
    phone: '+91 90000 33333',
  });

  const parentProfile = await makeUserProfile({
    email: 'rajesh.k@greenwood.edu',
    full_name: 'Rajesh Kumar',
    role: 'parent',
    organization_id: greenwood._id,
    phone: '+91 90000 44444',
  });

  const [sarah, amit] = await Teacher.create([
    {
      organization_id: greenwood._id,
      profile_id: teacherProfile._id,
      full_name: 'Sarah Johnson',
      email: 'sarah.j@greenwood.edu',
      phone: '+91 90000 22222',
      employee_id: 'T-1001',
      department: 'Science',
      subjects: 'Physics, Math',
      classes: '10-A, 9-B',
      status: 'Active',
      joining_date: new Date('2022-06-01'),
    },
    {
      organization_id: greenwood._id,
      profile_id: null,
      full_name: 'Amit Verma',
      email: 'amit.v@greenwood.edu',
      phone: '+91 90000 55555',
      employee_id: 'T-1002',
      department: 'Arts',
      subjects: 'English, History',
      classes: '8-A',
      status: 'Active',
      joining_date: new Date('2023-01-15'),
    },
  ]);

  const rajesh = await Parent.create({
    organization_id: greenwood._id,
    profile_id: parentProfile._id,
    full_name: 'Rajesh Kumar',
    email: 'rajesh.k@greenwood.edu',
    phone: '+91 90000 44444',
    occupation: 'Engineer',
    address: '45 Nehru Nagar, Delhi',
  });

  const [rahul] = await Student.create([
    {
      organization_id: greenwood._id,
      profile_id: studentProfile._id,
      admission_no: 'ADM-2024-001',
      full_name: 'Rahul Kumar',
      roll_no: '12',
      class_grade: '10',
      section: 'A',
      gender: 'Male',
      dob: new Date('2010-04-12'),
      phone: '+91 90000 33333',
      address: '45 Nehru Nagar, Delhi',
      teacher_id: sarah._id,
      status: 'Active',
    },
    {
      organization_id: greenwood._id,
      admission_no: 'ADM-2024-002',
      full_name: 'Priya Sharma',
      roll_no: '05',
      class_grade: '9',
      section: 'B',
      gender: 'Female',
      dob: new Date('2011-08-21'),
      address: '22 MG Road, Delhi',
      teacher_id: sarah._id,
      status: 'Active',
    },
    {
      organization_id: greenwood._id,
      admission_no: 'ADM-2024-003',
      full_name: 'Arjun Mehta',
      roll_no: '18',
      class_grade: '8',
      section: 'A',
      gender: 'Male',
      dob: new Date('2012-01-05'),
      address: '9 Civil Lines, Delhi',
      teacher_id: amit._id,
      status: 'Active',
    },
  ]);

  await ClassModel.create([
    { organization_id: greenwood._id, grade: '10', section: 'A', teacher_id: sarah._id },
    { organization_id: greenwood._id, grade: '9', section: 'B', teacher_id: sarah._id },
    { organization_id: greenwood._id, grade: '8', section: 'A', teacher_id: amit._id },
  ]);

  await StudentParent.create({ student_id: rahul._id, parent_id: rajesh._id });

  await Notice.create([
    {
      organization_id: greenwood._id,
      title: 'Welcome to the new term',
      description: 'Classes begin Monday. Please check the timetable.',
      audience: 'Everyone',
      color: 'blue',
      created_by: admin._id,
    },
    {
      organization_id: greenwood._id,
      title: 'PTM scheduled',
      description: 'Parent-teacher meeting on Friday at 4 PM.',
      audience: 'Parents',
      color: 'green',
      created_by: teacherProfile._id,
    },
  ]);

  console.log('Seed complete.');
  console.log('Demo logins (password: password123):');
  console.log('  superadmin@educore.edu');
  console.log('  admin@greenwood.edu');
  console.log('  sarah.j@greenwood.edu');
  console.log('  rahul.k@greenwood.edu');
  console.log('  rajesh.k@greenwood.edu');
  console.log(`Organizations: ${greenwood.code}, ${sunrise.code}`);
  process.exit(0);
}

seed().catch((err) => {
  console.error('Seed failed', err);
  process.exit(1);
});
