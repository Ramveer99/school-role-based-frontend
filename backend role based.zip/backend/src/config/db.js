import mongoose from 'mongoose';
import { env } from './env.js';

export async function connectDb() {
  mongoose.set('strictQuery', true);
  await mongoose.connect(env.mongodbUri);
  const safeUri = env.mongodbUri.replace(/\/\/([^:]+):([^@]+)@/, '//$1:***@');
  console.log(`[backend] MongoDB connected: ${safeUri}`);
}

export default connectDb;
