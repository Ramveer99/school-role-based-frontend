import { Router } from 'express';
import { profileHasRole, orgFilter } from '../middleware/auth.js';
import { Teacher } from '../models/index.js';
import { createAuthUser, resolveOrgId } from '../utils/users.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const rows = await Teacher.find(orgFilter(req.profile))
      .populate('organization_id', 'name')
      .sort({ created_at: -1 });

    const data = rows.map((t) => {
      const json = t.toJSON();
      return {
        ...json,
        organization: t.organization_id ? { name: t.organization_id.name } : null,
        organization_id: t.organization_id?._id?.toString?.() || json.organization_id,
      };
    });
    return res.json(data);
  } catch (err) {
    return next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['admin', 'super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const b = req.body || {};
    if (!b.full_name || !b.email || !b.employee_id) {
      return res.status(400).json({ error: 'full_name, email, employee_id required' });
    }

    const organization_id = resolveOrgId(req.profile, b.organization_id);
    if (!organization_id) return res.status(400).json({ error: 'organization_id required' });

    const userId = await createAuthUser({
      email: b.email,
      password: b.password || 'password123',
      full_name: b.full_name,
      role: 'teacher',
      organization_id,
      phone: b.phone,
    });

    const teacher = await Teacher.create({
      organization_id,
      profile_id: userId,
      full_name: b.full_name,
      email: b.email,
      phone: b.phone || null,
      employee_id: b.employee_id,
      department: b.department || null,
      subjects: b.subjects || null,
      classes: b.classes || null,
      status: b.status || 'Active',
      joining_date: b.joining_date || null,
    });

    return res.status(201).json(teacher.toJSON());
  } catch (err) {
    return next(err);
  }
});

router.put('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['admin', 'super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const { id, ...rest } = req.body || {};
    const filter = { _id: id, ...orgFilter(req.profile) };
    const teacher = await Teacher.findOneAndUpdate(filter, rest, { new: true });
    if (!teacher) return res.status(404).json({ error: 'Not found' });
    return res.json(teacher.toJSON());
  } catch (err) {
    return next(err);
  }
});

router.delete('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['admin', 'super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const { id } = req.body || {};
    await Teacher.findOneAndDelete({ _id: id, ...orgFilter(req.profile) });
    return res.json({ ok: true });
  } catch (err) {
    return next(err);
  }
});

export default router;
