import { Router } from 'express';
import { authenticateToken } from '../middleware/auth.js';
import auth from './auth.js';
import me from './me.js';
import organizations from './organizations.js';
import teachers from './teachers.js';
import students from './students.js';
import parents from './parents.js';
import classes from './classes.js';
import notices from './notices.js';
import admissions from './admissions.js';

const router = Router();

router.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'school-dashboard-api', db: 'mongodb' });
});

router.use('/auth', auth);

router.use(authenticateToken);

router.use('/me', me);
router.use('/organizations', organizations);
router.use('/teachers', teachers);
router.use('/students', students);
router.use('/parents', parents);
router.use('/classes', classes);
router.use('/notices', notices);
router.use('/admissions', admissions);

export default router;
