import { Router } from 'express';
import { profileHasRole, orgFilter } from '../middleware/auth.js';
import { Parent, StudentParent } from '../models/index.js';
import { createAuthUser, resolveOrgId } from '../utils/users.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const rows = await Parent.find(orgFilter(req.profile)).sort({ created_at: -1 });
    const parentIds = rows.map((p) => p._id);

    let children = [];
    if (parentIds.length) {
      children = await StudentParent.find({ parent_id: { $in: parentIds } }).populate(
        'student_id',
        'full_name class_grade section'
      );
    }

    const data = rows.map((p) => {
      const json = p.toJSON();
      return {
        ...json,
        children: children
          .filter((c) => c.parent_id.toString() === p._id.toString())
          .map((c) => (c.student_id ? c.student_id.toJSON() : null))
          .filter(Boolean),
      };
    });

    return res.json(data);
  } catch (err) {
    return next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['admin', 'super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const b = req.body || {};
    if (!b.full_name || !b.email) {
      return res.status(400).json({ error: 'full_name and email required' });
    }

    const organization_id = resolveOrgId(req.profile, b.organization_id);
    if (!organization_id) return res.status(400).json({ error: 'organization_id required' });

    const existing = await Parent.findOne({
      organization_id,
      email: b.email.toLowerCase(),
    });
    if (existing) return res.json(existing.toJSON());

    const userId = await createAuthUser({
      email: b.email,
      password: b.password || 'password123',
      full_name: b.full_name,
      role: 'parent',
      organization_id,
      phone: b.phone,
    });

    const parent = await Parent.create({
      organization_id,
      profile_id: userId,
      full_name: b.full_name,
      email: b.email,
      phone: b.phone || null,
      occupation: b.occupation || null,
      address: b.address || null,
    });

    return res.status(201).json(parent.toJSON());
  } catch (err) {
    return next(err);
  }
});

router.delete('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['admin', 'super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const { id } = req.body || {};
    await Parent.findOneAndDelete({ _id: id, ...orgFilter(req.profile) });
    await StudentParent.deleteMany({ parent_id: id });
    return res.json({ ok: true });
  } catch (err) {
    return next(err);
  }
});

export default router;
