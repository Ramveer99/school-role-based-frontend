import { Router } from 'express';
import mongoose from 'mongoose';
import { orgFilter } from '../middleware/auth.js';
import { ClassModel, Student, Teacher, Parent, StudentParent } from '../models/index.js';

const router = Router();

async function classFilterForProfile(profile) {
  const base = orgFilter(profile);

  if (profile.role === 'admin' || profile.role === 'super_admin') {
    return base;
  }

  if (profile.role === 'student') {
    const student = await Student.findOne({
      profile_id: new mongoose.Types.ObjectId(profile.id),
      ...orgFilter(profile),
    });
    if (!student?.class_grade || !student?.section) return { ...base, _id: { $in: [] } };
    return { ...base, grade: student.class_grade, section: student.section };
  }

  if (profile.role === 'teacher') {
    const teacher = await Teacher.findOne({
      profile_id: new mongoose.Types.ObjectId(profile.id),
      ...orgFilter(profile),
    });
    if (!teacher) return { ...base, _id: { $in: [] } };
    return { ...base, teacher_id: teacher._id };
  }

  if (profile.role === 'parent') {
    const parent = await Parent.findOne({
      profile_id: new mongoose.Types.ObjectId(profile.id),
    });
    if (!parent) return { ...base, _id: { $in: [] } };
    const links = await StudentParent.find({ parent_id: parent._id }).select('student_id');
    const ids = links.map((l) => l.student_id);
    if (!ids.length) return { ...base, _id: { $in: [] } };
    const children = await Student.find({ _id: { $in: ids } }).select('class_grade section');
    const pairs = [...new Map(
      children
        .filter((s) => s.class_grade && s.section)
        .map((s) => [`${s.class_grade}-${s.section}`, { grade: s.class_grade, section: s.section }])
    ).values()];
    if (!pairs.length) return { ...base, _id: { $in: [] } };
    return { ...base, $or: pairs };
  }

  return { ...base, _id: { $in: [] } };
}

router.get('/', async (req, res, next) => {
  try {
    const profile = req.profile;
    const rows = await ClassModel.find(await classFilterForProfile(profile))
      .populate('teacher_id', 'full_name')
      .sort({ grade: 1, section: 1 });

    const studentFilter = orgFilter(profile);
    const students = await Student.find(studentFilter).select('class_grade section organization_id');

    const data = rows.map((c) => {
      const json = c.toJSON();
      const orgId = c.organization_id.toString();
      return {
        ...json,
        teacher_id: c.teacher_id?._id?.toString?.() || json.teacher_id,
        teacher_name: c.teacher_id?.full_name || null,
        student_count: students.filter(
          (s) =>
            s.class_grade === c.grade &&
            s.section === c.section &&
            (profile.role === 'super_admin' ? s.organization_id.toString() === orgId : true)
        ).length,
      };
    });

    return res.json(data);
  } catch (err) {
    return next(err);
  }
});

export default router;
