import { Router } from 'express';
import { profileHasRole } from '../middleware/auth.js';
import { Parent, Student, ClassModel, StudentParent } from '../models/index.js';
import { createAuthUser, resolveOrgId } from '../utils/users.js';

const router = Router();

router.post('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['admin', 'super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const body = req.body || {};
    const stu = body.student || {};
    if (!stu.full_name || !stu.admission_no) {
      return res.status(400).json({ error: 'student.full_name and student.admission_no required' });
    }

    const organization_id = resolveOrgId(req.profile, body.organization_id || stu.organization_id);
    if (!organization_id) return res.status(400).json({ error: 'organization_id required' });

    if (!stu.email) {
      return res.status(400).json({ error: 'student.email required for login' });
    }

    let parentId = null;
    if (body.parent_id) {
      const p = await Parent.findById(body.parent_id);
      if (!p || p.organization_id.toString() !== organization_id.toString()) {
        return res.status(400).json({ error: 'Invalid parent for this organization' });
      }
      parentId = p._id;
    } else if (body.parent) {
      const par = body.parent;
      if (!par.full_name || !par.email) {
        return res.status(400).json({ error: 'parent.full_name and parent.email required' });
      }

      const existing = await Parent.findOne({
        organization_id,
        email: par.email.toLowerCase(),
      });

      if (existing) {
        parentId = existing._id;
      } else {
        const userId = await createAuthUser({
          email: par.email,
          full_name: par.full_name,
          role: 'parent',
          organization_id,
          phone: par.phone,
        });
        const newParent = await Parent.create({
          organization_id,
          profile_id: userId,
          full_name: par.full_name,
          email: par.email,
          phone: par.phone || null,
          occupation: par.occupation || null,
          address: par.address || null,
        });
        parentId = newParent._id;
      }
    }

    if (stu.class_grade && stu.section) {
      const existingClass = await ClassModel.findOne({
        organization_id,
        grade: String(stu.class_grade),
        section: stu.section,
      });

      if (!existingClass) {
        await ClassModel.create({
          organization_id,
          grade: String(stu.class_grade),
          section: stu.section,
          teacher_id: stu.teacher_id || null,
        });
      } else if (stu.teacher_id) {
        existingClass.teacher_id = stu.teacher_id;
        await existingClass.save();
      }
    }

    const studentProfileId = await createAuthUser({
      email: stu.email,
      full_name: stu.full_name,
      role: 'student',
      organization_id,
      phone: stu.phone,
    });

    const student = await Student.create({
      organization_id,
      profile_id: studentProfileId,
      admission_no: stu.admission_no,
      full_name: stu.full_name,
      roll_no: stu.roll_no || null,
      class_grade: String(stu.class_grade || ''),
      section: stu.section || null,
      gender: stu.gender || null,
      dob: stu.dob || null,
      phone: stu.phone || null,
      address: stu.address || null,
      teacher_id: stu.teacher_id || null,
      status: 'Active',
    });

    if (parentId) {
      const existingLink = await StudentParent.findOne({
        student_id: student._id,
        parent_id: parentId,
      });
      if (!existingLink) {
        await StudentParent.create({ student_id: student._id, parent_id: parentId });
      }
    }

    return res.status(201).json({
      ok: true,
      student: student.toJSON(),
      parent_id: parentId?.toString?.() || parentId,
    });
  } catch (err) {
    return next(err);
  }
});

export default router;
