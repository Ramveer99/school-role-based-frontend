import { Router } from 'express';
import { profileHasRole } from '../middleware/auth.js';
import { Organization, Student, Teacher, Parent } from '../models/index.js';
import { createAuthUser } from '../utils/users.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const orgs = await Organization.find().sort({ created_at: -1 });

    const withStats = await Promise.all(
      orgs.map(async (o) => {
        const id = o._id;
        const [students, teachers, parents] = await Promise.all([
          Student.countDocuments({ organization_id: id }),
          Teacher.countDocuments({ organization_id: id }),
          Parent.countDocuments({ organization_id: id }),
        ]);
        return { ...o.toJSON(), stats: { students, teachers, parents } };
      })
    );

    return res.json(withStats);
  } catch (err) {
    return next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['super_admin'])) {
      return res.status(403).json({ error: 'Only Super Admin can create organizations' });
    }

    const { name, code, address, phone, email, admin_name, admin_email } = req.body || {};
    if (!name || !code) return res.status(400).json({ error: 'name and code required' });

    const org = await Organization.create({
      name,
      code: code.toUpperCase(),
      address,
      phone,
      email,
      active: true,
    });

    if (admin_email) {
      await createAuthUser({
        email: admin_email,
        full_name: admin_name || admin_email,
        role: 'admin',
        organization_id: org._id,
      });
    }

    return res.status(201).json(org.toJSON());
  } catch (err) {
    return next(err);
  }
});

router.put('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const { id, ...rest } = req.body || {};
    const org = await Organization.findByIdAndUpdate(id, rest, { new: true });
    if (!org) return res.status(404).json({ error: 'Not found' });
    return res.json(org.toJSON());
  } catch (err) {
    return next(err);
  }
});

router.delete('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const { id } = req.body || {};
    await Organization.findByIdAndDelete(id);
    return res.json({ ok: true });
  } catch (err) {
    return next(err);
  }
});

export default router;
