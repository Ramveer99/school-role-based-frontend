import { Router } from 'express';
import mongoose from 'mongoose';
import { profileHasRole, orgFilter } from '../middleware/auth.js';
import { Student, Parent, StudentParent } from '../models/index.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const profile = req.profile;
    let filter = orgFilter(profile);

    if (profile.role === 'parent') {
      const parent = await Parent.findOne({ profile_id: new mongoose.Types.ObjectId(profile.id) });
      if (!parent) return res.json([]);
      const links = await StudentParent.find({ parent_id: parent._id }).select('student_id');
      const ids = links.map((l) => l.student_id);
      filter = { ...filter, _id: { $in: ids.length ? ids : [] } };
    }

    if (profile.role === 'student') {
      filter = { ...filter, profile_id: new mongoose.Types.ObjectId(profile.id) };
    }

    const rows = await Student.find(filter).populate('teacher_id', 'full_name').sort({ created_at: -1 });
    const ids = rows.map((s) => s._id);
    

    const parentMap = {};
    if (ids.length) {
      const links = await StudentParent.find({ student_id: { $in: ids } }).populate('parent_id', 'full_name');
      links.forEach((l) => {
        if (l.parent_id) parentMap[l.student_id.toString()] = l.parent_id.full_name;
      });
    }

    const data = rows.map((s) => {
      const json = s.toJSON();
      return {
        ...json,
        teacher_id: s.teacher_id?._id?.toString?.() || json.teacher_id,
        teacher_name: s.teacher_id?.full_name || null,
        parent_name: parentMap[s._id.toString()] || null,
      };
    });

    return res.json(data);
  } catch (err) {
    return next(err);
  }
});

router.delete('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['admin', 'super_admin'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const { id } = req.body || {};
    await Student.findOneAndDelete({ _id: id, ...orgFilter(req.profile) });
    await StudentParent.deleteMany({ student_id: id });
    return res.json({ ok: true });
  } catch (err) {
    return next(err);
  }
});

export default router;
