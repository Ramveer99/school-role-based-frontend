import { Router } from 'express';
import { authenticateToken, profileHasRole } from '../middleware/auth.js';
import {
  loginWithEmailPassword,
  registerUser,
  getMeFromProfileId,
  requestPasswordReset,
  resetPasswordWithToken,
} from '../services/authService.js';
import { resolveOrgId } from '../utils/users.js';

const router = Router();

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ error: 'email and password required' });
    }

    const result = await loginWithEmailPassword(email, password);
    if (result.error) {
      return res.status(result.status || 401).json({ error: result.error });
    }

    return res.json({ token: result.token, user: result.user });
  } catch (err) {
    return next(err);
  }
});

router.post('/register', authenticateToken, async (req, res, next) => {
  try {
    const actor = req.profile;
    const { email, password, full_name, role, organization_id, phone } = req.body || {};

    if (!email || !password || !full_name || !role) {
      return res.status(400).json({ error: 'email, password, full_name, and role required' });
    }

    const allowedRoles = ['admin', 'teacher', 'student', 'parent'];
    if (!allowedRoles.includes(role)) {
      return res.status(400).json({ error: 'Invalid role for registration' });
    }

    if (profileHasRole(actor, ['super_admin'])) {
      // super admin can create any org user
    } else if (profileHasRole(actor, ['admin'])) {
      if (role === 'admin') {
        return res.status(403).json({ error: 'Forbidden' });
      }
    } else {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const orgId = resolveOrgId(actor, organization_id);
    if (!orgId) {
      return res.status(400).json({ error: 'organization_id required' });
    }

    const result = await registerUser({
      email,
      password,
      full_name,
      role,
      organization_id: orgId,
      phone,
    });

    if (result.error) {
      return res.status(result.status || 400).json({
        error: result.error,
        duplicate: result.duplicate || false,
      });
    }

    return res.status(201).json({ token: result.token, user: result.user });
  } catch (err) {
    return next(err);
  }
});

router.post('/logout', (_req, res) => {
  res.json({ ok: true, message: 'Logged out. Discard the JWT on the client.' });
});

router.get('/me', authenticateToken, async (req, res, next) => {
  try {
    const me = await getMeFromProfileId(req.profile.id);
    if (!me) return res.status(404).json({ error: 'Profile not found' });
    return res.json(me);
  } catch (err) {
    return next(err);
  }
});

router.post('/forgot-password', async (req, res, next) => {
  try {
    const { email } = req.body || {};
    if (!email) return res.status(400).json({ error: 'email required' });

    const result = await requestPasswordReset(email);
    const payload = { ok: result.ok, message: result.message };
    if (process.env.NODE_ENV !== 'production' && result.resetToken) {
      payload.resetToken = result.resetToken;
    }
    return res.json(payload);
  } catch (err) {
    return next(err);
  }
});

router.post('/reset-password', async (req, res, next) => {
  try {
    const { token, password } = req.body || {};
    const result = await resetPasswordWithToken(token, password);
    if (result.error) {
      return res.status(result.status || 400).json({ error: result.error });
    }
    return res.json({ ok: true });
  } catch (err) {
    return next(err);
  }
});

export default router;
