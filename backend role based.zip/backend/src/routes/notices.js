import { Router } from 'express';
import { profileHasRole, orgFilter } from '../middleware/auth.js';
import { Notice } from '../models/index.js';
import { resolveOrgId } from '../utils/users.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const rows = await Notice.find(orgFilter(req.profile)).sort({ created_at: -1 });
    return res.json(rows.map((n) => n.toJSON()));
  } catch (err) {
    return next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    if (!profileHasRole(req.profile, ['admin', 'super_admin', 'teacher'])) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const b = req.body || {};
    const organization_id = resolveOrgId(req.profile, b.organization_id);
    if (!organization_id) return res.status(400).json({ error: 'organization_id required' });

    const notice = await Notice.create({
      organization_id,
      title: b.title,
      description: b.description,
      audience: b.audience || 'Everyone',
      color: b.color || 'blue',
      created_by: req.profile.id,
    });

    return res.status(201).json(notice.toJSON());
  } catch (err) {
    return next(err);
  }
});

export default router;
