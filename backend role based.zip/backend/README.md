# EduCore API (Express + MongoDB)

## Run

```bash
cp .env.example .env   # from repo root or backend/
npm install
npm run dev            # from backend, or npm run dev:api from root
```

## Auth

| Method | Path | Auth |
|--------|------|------|
| POST | `/api/auth/login` | Public |
| POST | `/api/auth/register` | Bearer (admin / super_admin) |
| POST | `/api/auth/logout` | Optional Bearer |
| GET | `/api/auth/me` | Bearer |
| POST | `/api/auth/forgot-password` | Public |
| POST | `/api/auth/reset-password` | Public |

Legacy: `GET /api/me` (same payload as `/api/auth/me`).

## Data migration

1. **From Supabase (production data)** — does not delete Supabase rows:

   ```bash
   # Set SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, SUPABASE_DATABASE_URL, MONGODB_URI
   npm run migrate:supabase
   ```

   Maps Supabase UUIDs / bigint IDs → new MongoDB ObjectIds via `legacy_supabase_id` fields.

2. **Legacy Mongo (password on `profiles`)**:

   ```bash
   npm run upgrade:legacy-auth
   ```

3. **Ad-hoc `users` documents** (role / organizationId on user):

   ```bash
   npm run normalize:users
   ```

4. **Demo seed only** (wipes MongoDB collections):

   ```bash
   npm run seed
   ```

## MongoDB Compass: no data?

1. **Same connection as the API** — `MONGODB_URI` in `.env` must match the cluster/host you open in Compass (local `127.0.0.1` vs Atlas `mongodb+srv://...` are different servers).
2. **Database name `school_dashboard`** — EduCore does not use the `school-saas` database or a `sections` collection. Open:
   - `organizations`, `users`, `profiles`, `students`, `teachers`, `parents`, `classes`, `notices`, `studentparents`
3. **Load data** — empty until you run one of:
   - `npm run migrate:supabase` (real Supabase data)
   - `npm run seed` (demo data; wipes existing data in that database)

Check counts: `node scripts/inspectMongo.js`
